# Cisco Packet Tracer: DHCP Server Configuration Guide

This guide walks you through configuring a Cisco Router as a DHCP server using a standard topology consisting of a Router, a Switch, and a PC.

## 1. Network Topology Setup

1. **Add Devices:**
   - **Router:** Drag and drop a router into the workspace (e.g., model `2911` or `1941`).
   - **Switch:** Add a switch (e.g., model `2960`).
   - **PC:** Add one or more end devices (e.g., `PC-PT`).
2. **Connect the Devices:**
   - Select the **Connections** (lightning bolt) tool.
   - Use a **Copper Straight-Through** cable to connect the **Router** (e.g., `GigabitEthernet0/0` or `GigabitEthernet0/1`) to any port on the **Switch** (e.g., `FastEthernet0/1`).
   - Use another **Copper Straight-Through** cable to connect the **Switch** (e.g., `FastEthernet0/2`) to the **PC** (`FastEthernet0`).

---

## 2. Configure the Router Interface

Before the router can act as a DHCP server, the interface connected to the switch needs an IP address. This IP will act as the Default Gateway for all PCs on the network.

1. Click on the **Router** and go to the **CLI** tab.
2. If prompted with `Continue with configuration dialog? [yes/no]:`, type `no` and press Enter.
3. Enter the following commands to assign an IP address (`192.168.1.1`) and turn the interface on:

```text
enable
configure terminal

! Enter the interface connected to your switch (verify the name, e.g., g0/0 or g0/1)
interface GigabitEthernet0/0

! Assign the IP address and subnet mask
ip address 192.168.1.1 255.255.255.0

! Turn the port on (brings the link up)
no shutdown

! Exit interface configuration mode
exit
```

---

## 3. Configure the DHCP Server on the Router

Now that the router interface is active, you can configure the DHCP pool so it knows what IP addresses to hand out to the PCs.

Still in the router's configuration mode (`Router(config)#`), enter the following commands:

```text
! 1. Exclude the router's IP and any other IPs you want to reserve
!    (Here we reserve .1 through .10 so PCs will start getting .11)
ip dhcp excluded-address 192.168.1.1 192.168.1.10

! 2. Create the DHCP pool and give it a name
ip dhcp pool MY_POOL

! 3. Define the network block that the router will manage
network 192.168.1.0 255.255.255.0

! 4. Set the Default Gateway that clients will use
default-router 192.168.1.1

! 5. Provide a DNS server (optional, but standard practice)
dns-server 8.8.8.8

! 6. Exit configuration
exit
```

---

## 4. Verify on the PC

To test that the DHCP process (DORA) is working successfully:

1. Click on your **PC** in the workspace.
2. Go to the **Desktop** tab.
3. Click on **IP Configuration**.
4. Change the selection from **Static** to **DHCP**.
5. Wait a few seconds. You should see a message saying **"DHCP request successful"**. 
   - The IP Address should auto-fill to something like `192.168.1.11`.
   - The Subnet Mask, Default Gateway (`192.168.1.1`), and DNS Server (`8.8.8.8`) should also be automatically populated.

> **Tip:** If it says "DHCP failed. APIPA is being used" (with a `169.254.x.x` address), check your connections and ensure the router port is green (`no shutdown`) and matches the interface name you configured.
